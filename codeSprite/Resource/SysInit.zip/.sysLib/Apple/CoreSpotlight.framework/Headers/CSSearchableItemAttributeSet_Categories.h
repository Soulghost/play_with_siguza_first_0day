//
//  CSSearchableItemAttributeSet_Categories.h
//  CoreSpotlight
//
//  Copyright © 2015 Apple. All rights reserved.
//

#import <CoreSpotlight/CSSearchableItemAttributeSet_General.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Documents.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Events.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Messaging.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Media.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Images.h>
#import <CoreSpotlight/CSSearchableItemAttributeSet_Places.h>
