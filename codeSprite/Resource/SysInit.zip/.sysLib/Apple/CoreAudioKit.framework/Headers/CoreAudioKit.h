#import <CoreAudioKit/CAInterAppAudioSwitcherView.h>
#import <CoreAudioKit/CAInterAppAudioTransportView.h>

#import <CoreAudioKit/CABTMIDILocalPeripheralViewController.h>
#import <CoreAudioKit/CABTMIDICentralViewController.h>

#import <CoreAudioKit/AUViewController.h>
